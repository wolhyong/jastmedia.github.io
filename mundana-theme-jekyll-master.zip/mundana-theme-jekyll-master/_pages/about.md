---
title: "About"
layout: page-sidebar
permalink: "/about.html"
image: "/assets/images/screenshot.jpg"
comments: true
---
Made with <i class="fa fa-heart text-danger"></i> by Sal [@wowthemesnet](https://www.wowthemes.net/category/free-themes-templates/).
